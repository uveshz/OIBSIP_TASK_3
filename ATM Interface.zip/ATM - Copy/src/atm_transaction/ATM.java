package atm_transaction;
public class ATM {
    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}
